"""Standard-library bank validation helpers."""
